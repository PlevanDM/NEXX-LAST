// Shared Components for NEXX v9.0
// Header and Footer used across all pages

const { createElement: h } = React;

// Header Component
function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navItems = [
    { href: '/', label: 'Acasă', icon: 'fa-home' },
    { href: '/about.html', label: 'Despre noi', icon: 'fa-info-circle' },
    { href: '/calculator', label: 'Calculator', icon: 'fa-calculator' },
    { href: '/faq.html', label: 'FAQ', icon: 'fa-question-circle' }
  ];

  const masterItems = [
    { href: '/nexx', label: 'Bază de date', icon: 'fa-database' },
    { href: '/test-click', label: 'Testare', icon: 'fa-vial' }
  ];

  return h('header', { className: 'fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm' },
    h('div', { className: 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8' },
      h('div', { className: 'flex items-center justify-between h-16' },
        // Logo
        h('a', { href: '/', className: 'flex items-center gap-2 group' },
          h('img', {
            src: '/static/nexx-logo.png',
            alt: 'NEXX GSM',
            className: 'h-10 w-auto object-contain transition-transform duration-300 group-hover:scale-105'
          }),
          h('span', { className: 'sr-only' }, 'NEXX GSM')
        ),

        // Desktop Navigation
        h('nav', { className: 'hidden md:flex items-center gap-8' },
          ...navItems.map(item =>
            h('a', {
              key: item.href,
              href: item.href,
              className: 'text-gray-700 hover:text-gray-900 font-medium transition-colors duration-200 flex items-center gap-2'
            },
              h('i', { className: `fas ${item.icon} text-sm` }),
              item.label
            )
          ),
          // Masters Dropdown
          h('div', { className: 'relative group' },
            h('button', { className: 'text-gray-700 hover:text-gray-900 font-medium transition-colors duration-200 flex items-center gap-2' },
              h('i', { className: 'fas fa-tools text-sm' }),
              'Pentru profesioniști',
              h('i', { className: 'fas fa-chevron-down text-xs ml-1 group-hover:rotate-180 transition-transform duration-300' })
            ),
            h('div', { className: 'absolute top-full right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 py-2' },
              ...masterItems.map(item =>
                h('a', {
                  key: item.href,
                  href: item.href,
                  className: 'flex items-center gap-3 px-4 py-2 text-gray-700 hover:bg-gray-100 hover:text-gray-900 transition-colors duration-200'
                },
                  h('i', { className: `fas ${item.icon} text-sm` }),
                  item.label
                )
              )
            )
          )
        ),

        // CTA Button + Mobile Menu
        h('div', { className: 'flex items-center gap-4' },
          // Call Button
          h('a', {
            href: 'tel:+380000000000',
            className: 'hidden sm:inline-flex items-center gap-2 px-4 py-2 bg-gray-900 text-white font-semibold rounded-xl hover:bg-black transition-all duration-200 shadow-md hover:shadow-lg'
          },
            h('i', { className: 'fas fa-phone' }),
            h('span', { className: 'hidden lg:inline' }, 'Sună acum')
          ),

          // Mobile Menu Button
          h('button', {
            onClick: () => setMobileMenuOpen(!mobileMenuOpen),
            className: 'md:hidden p-2 text-gray-700 hover:text-gray-900 transition-colors'
          },
            h('i', { className: `fas ${mobileMenuOpen ? 'fa-times' : 'fa-bars'} text-xl` })
          )
        )
      ),

      // Mobile Menu
      mobileMenuOpen && h('nav', { className: 'md:hidden py-4 border-t border-gray-200' },
        h('div', { className: 'flex flex-col gap-2' },
          ...navItems.map(item =>
            h('a', {
              key: item.href,
              href: item.href,
              className: 'flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-lg transition-colors duration-200'
            },
              h('i', { className: `fas ${item.icon}` }),
              item.label
            )
          ),
          h('div', { className: 'border-t border-gray-200 mt-2 pt-2' },
            h('div', { className: 'px-4 py-2 text-xs font-semibold text-gray-500 uppercase' }, 'Pentru profesioniști'),
            ...masterItems.map(item =>
              h('a', {
                key: item.href,
                href: item.href,
                className: 'flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-lg transition-colors duration-200'
              },
                h('i', { className: `fas ${item.icon}` }),
                item.label
              )
            )
          )
        )
      )
    )
  );
}

// Footer Component
function Footer() {
  // Safe translation function with fallback
  const t = (key) => {
    try {
      return window.i18n?.t?.(key) || key.split('.').pop();
    } catch {
      return key.split('.').pop();
    }
  };

  const footerLinks = {
    'Про нас': [
      { href: '/about.html', label: 'Наștoria noastră' },
      { href: '/about.html#team', label: 'Команда' },
      { href: '/about.html#values', label: 'Цінності' }
    ],
    'Послуги': [
      { href: '/calculator', label: 'Калькулятор цін' },
      { href: '/#services', label: 'Всі послуги' },
      { href: '/#pricing', label: 'Тарифи' }
    ],
    'Інформація': [
      { href: '/faq.html', label: 'FAQ' },
      { href: '/privacy.html', label: 'Конфіденційність' },
      { href: '/terms.html', label: 'Умови використання' }
    ]
  };

  const socialLinks = [
    { href: 'https://www.instagram.com/', icon: 'fa-instagram', label: 'Instagram', color: 'hover:text-pink-600' },
    { href: 'https://t.me/', icon: 'fa-telegram', label: 'Telegram', color: 'hover:text-blue-500' },
    { href: 'https://www.facebook.com/', icon: 'fa-facebook', label: 'Facebook', color: 'hover:text-blue-600' }
  ];

  return h('footer', { className: 'bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white pt-16 pb-8' },
    h('div', { className: 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8' },
      h('div', { className: 'grid md:grid-cols-4 gap-8 mb-12' },
        // Brand Column
        h('div', null,
          h('div', { className: 'flex items-center gap-2 mb-4' },
            h('div', { className: 'w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg' },
              h('span', { className: 'text-white font-bold text-xl' }, 'N')
            ),
            h('span', { className: 'text-2xl font-bold' }, 'NEXX')
          ),
          h('p', { className: 'text-blue-200 text-sm leading-relaxed mb-4' },
            t('footer.tagline')
          ),
          h('div', { className: 'flex gap-3' },
            ...socialLinks.map(social =>
              h('a', {
                key: social.href,
                href: social.href,
                target: '_blank',
                rel: 'noopener noreferrer',
                className: `w-10 h-10 bg-white/10 hover:bg-white/20 rounded-lg flex items-center justify-center transition-all duration-200 ${social.color}`,
                'aria-label': social.label
              },
                h('i', { className: `fab ${social.icon} text-lg` })
              )
            )
          )
        ),

        // Links Columns
        ...Object.entries(footerLinks).map(([title, links]) =>
          h('div', { key: title },
            h('h3', { className: 'font-bold text-lg mb-4' }, title),
            h('ul', { className: 'space-y-2' },
              ...links.map(link =>
                h('li', { key: link.href },
                  h('a', {
                    href: link.href,
                    className: 'text-blue-200 hover:text-white transition-colors duration-200 text-sm'
                  }, link.label)
                )
              )
            )
          )
        )
      ),

      // Bottom Bar
      h('div', { className: 'border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4' },
        h('p', { className: 'text-blue-200 text-sm' },
          '© 2026 NEXX Service Center. Toate drepturile rezervate.'
        ),
        h('div', { className: 'flex gap-6 text-sm' },
          h('a', { href: '/privacy.html', className: 'text-blue-200 hover:text-white transition-colors' }, 'Конфіденційність'),
          h('a', { href: '/terms.html', className: 'text-blue-200 hover:text-white transition-colors' }, 'Умови використання')
        )
      )
    )
  );
}

// Export for use in other files
if (typeof window !== 'undefined') {
  window.NEXXShared = { Header, Footer };
}
