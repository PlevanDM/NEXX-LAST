var B=(e,t,r)=>(s,n)=>{let o=-1;return i(0);async function i(l){if(l<=o)throw new Error("next() called multiple times");o=l;let a,c=!1,d;if(e[l]?(d=e[l][0][0],s.req.routeIndex=l):d=l===e.length&&n||void 0,d)try{a=await d(s,()=>i(l+1))}catch(h){if(h instanceof Error&&t)s.error=h,a=await t(h,s),c=!0;else throw h}else s.finalized===!1&&r&&(a=await r(s));return a&&(s.finalized===!1||c)&&(s.res=a),s}},ue=Symbol(),fe=async(e,t=Object.create(null))=>{const{all:r=!1,dot:s=!1}=t,o=(e instanceof Q?e.raw.headers:e.headers).get("Content-Type");return o?.startsWith("multipart/form-data")||o?.startsWith("application/x-www-form-urlencoded")?pe(e,{all:r,dot:s}):{}};async function pe(e,t){const r=await e.formData();return r?ge(r,t):{}}function ge(e,t){const r=Object.create(null);return e.forEach((s,n)=>{t.all||n.endsWith("[]")?me(r,n,s):r[n]=s}),t.dot&&Object.entries(r).forEach(([s,n])=>{s.includes(".")&&(ye(r,s,n),delete r[s])}),r}var me=(e,t,r)=>{e[t]!==void 0?Array.isArray(e[t])?e[t].push(r):e[t]=[e[t],r]:t.endsWith("[]")?e[t]=[r]:e[t]=r},ye=(e,t,r)=>{let s=e;const n=t.split(".");n.forEach((o,i)=>{i===n.length-1?s[o]=r:((!s[o]||typeof s[o]!="object"||Array.isArray(s[o])||s[o]instanceof File)&&(s[o]=Object.create(null)),s=s[o])})},W=e=>{const t=e.split("/");return t[0]===""&&t.shift(),t},be=e=>{const{groups:t,path:r}=we(e),s=W(r);return ve(s,t)},we=e=>{const t=[];return e=e.replace(/\{[^}]+\}/g,(r,s)=>{const n=`@${s}`;return t.push([n,r]),n}),{groups:t,path:e}},ve=(e,t)=>{for(let r=t.length-1;r>=0;r--){const[s]=t[r];for(let n=e.length-1;n>=0;n--)if(e[n].includes(s)){e[n]=e[n].replace(s,t[r][1]);break}}return e},H={},xe=(e,t)=>{if(e==="*")return"*";const r=e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(r){const s=`${e}#${t}`;return H[s]||(r[2]?H[s]=t&&t[0]!==":"&&t[0]!=="*"?[s,r[1],new RegExp(`^${r[2]}(?=/${t})`)]:[e,r[1],new RegExp(`^${r[2]}$`)]:H[s]=[e,r[1],!0]),H[s]}return null},X=(e,t)=>{try{return t(e)}catch{return e.replace(/(?:%[0-9A-Fa-f]{2})+/g,r=>{try{return t(r)}catch{return r}})}},Ee=e=>X(e,decodeURI),z=e=>{const t=e.url,r=t.indexOf("/",t.indexOf(":")+4);let s=r;for(;s<t.length;s++){const n=t.charCodeAt(s);if(n===37){const o=t.indexOf("?",s),i=t.slice(r,o===-1?void 0:o);return Ee(i.includes("%25")?i.replace(/%25/g,"%2525"):i)}else if(n===63)break}return t.slice(r,s)},Re=e=>{const t=z(e);return t.length>1&&t.at(-1)==="/"?t.slice(0,-1):t},A=(e,t,...r)=>(r.length&&(t=A(t,...r)),`${e?.[0]==="/"?"":"/"}${e}${t==="/"?"":`${e?.at(-1)==="/"?"":"/"}${t?.[0]==="/"?t.slice(1):t}`}`),V=e=>{if(e.charCodeAt(e.length-1)!==63||!e.includes(":"))return null;const t=e.split("/"),r=[];let s="";return t.forEach(n=>{if(n!==""&&!/\:/.test(n))s+="/"+n;else if(/\:/.test(n))if(/\?/.test(n)){r.length===0&&s===""?r.push("/"):r.push(s);const o=n.replace("?","");s+="/"+o,r.push(s)}else s+="/"+n}),r.filter((n,o,i)=>i.indexOf(n)===o)},I=e=>/[%+]/.test(e)?(e.indexOf("+")!==-1&&(e=e.replace(/\+/g," ")),e.indexOf("%")!==-1?X(e,Y):e):e,J=(e,t,r)=>{let s;if(!r&&t&&!/[%+]/.test(t)){let i=e.indexOf("?",8);if(i===-1)return;for(e.startsWith(t,i+1)||(i=e.indexOf(`&${t}`,i+1));i!==-1;){const l=e.charCodeAt(i+t.length+1);if(l===61){const a=i+t.length+2,c=e.indexOf("&",a);return I(e.slice(a,c===-1?void 0:c))}else if(l==38||isNaN(l))return"";i=e.indexOf(`&${t}`,i+1)}if(s=/[%+]/.test(e),!s)return}const n={};s??=/[%+]/.test(e);let o=e.indexOf("?",8);for(;o!==-1;){const i=e.indexOf("&",o+1);let l=e.indexOf("=",o);l>i&&i!==-1&&(l=-1);let a=e.slice(o+1,l===-1?i===-1?void 0:i:l);if(s&&(a=I(a)),o=i,a==="")continue;let c;l===-1?c="":(c=e.slice(l+1,i===-1?void 0:i),s&&(c=I(c))),r?(n[a]&&Array.isArray(n[a])||(n[a]=[]),n[a].push(c)):n[a]??=c}return t?n[t]:n},Pe=J,Oe=(e,t)=>J(e,t,!0),Y=decodeURIComponent,U=e=>X(e,Y),Q=class{raw;#t;#e;routeIndex=0;path;bodyCache={};constructor(e,t="/",r=[[]]){this.raw=e,this.path=t,this.#e=r,this.#t={}}param(e){return e?this.#r(e):this.#o()}#r(e){const t=this.#e[0][this.routeIndex][1][e],r=this.#n(t);return r&&/\%/.test(r)?U(r):r}#o(){const e={},t=Object.keys(this.#e[0][this.routeIndex][1]);for(const r of t){const s=this.#n(this.#e[0][this.routeIndex][1][r]);s!==void 0&&(e[r]=/\%/.test(s)?U(s):s)}return e}#n(e){return this.#e[1]?this.#e[1][e]:e}query(e){return Pe(this.url,e)}queries(e){return Oe(this.url,e)}header(e){if(e)return this.raw.headers.get(e)??void 0;const t={};return this.raw.headers.forEach((r,s)=>{t[s]=r}),t}async parseBody(e){return this.bodyCache.parsedBody??=await fe(this,e)}#s=e=>{const{bodyCache:t,raw:r}=this,s=t[e];if(s)return s;const n=Object.keys(t)[0];return n?t[n].then(o=>(n==="json"&&(o=JSON.stringify(o)),new Response(o)[e]())):t[e]=r[e]()};json(){return this.#s("text").then(e=>JSON.parse(e))}text(){return this.#s("text")}arrayBuffer(){return this.#s("arrayBuffer")}blob(){return this.#s("blob")}formData(){return this.#s("formData")}addValidatedData(e,t){this.#t[e]=t}valid(e){return this.#t[e]}get url(){return this.raw.url}get method(){return this.raw.method}get[ue](){return this.#e}get matchedRoutes(){return this.#e[0].map(([[,e]])=>e)}get routePath(){return this.#e[0].map(([[,e]])=>e)[this.routeIndex].path}},Se={Stringify:1},Z=async(e,t,r,s,n)=>{typeof e=="object"&&!(e instanceof String)&&(e instanceof Promise||(e=e.toString()),e instanceof Promise&&(e=await e));const o=e.callbacks;return o?.length?(n?n[0]+=e:n=[e],Promise.all(o.map(l=>l({phase:t,buffer:n,context:s}))).then(l=>Promise.all(l.filter(Boolean).map(a=>Z(a,t,!1,s,n))).then(()=>n[0]))):Promise.resolve(e)},Ce="text/plain; charset=UTF-8",_=(e,t)=>({"Content-Type":e,...t}),Ae=class{#t;#e;env={};#r;finalized=!1;error;#o;#n;#s;#d;#c;#l;#a;#h;#u;constructor(e,t){this.#t=e,t&&(this.#n=t.executionCtx,this.env=t.env,this.#l=t.notFoundHandler,this.#u=t.path,this.#h=t.matchResult)}get req(){return this.#e??=new Q(this.#t,this.#u,this.#h),this.#e}get event(){if(this.#n&&"respondWith"in this.#n)return this.#n;throw Error("This context has no FetchEvent")}get executionCtx(){if(this.#n)return this.#n;throw Error("This context has no ExecutionContext")}get res(){return this.#s||=new Response(null,{headers:this.#a??=new Headers})}set res(e){if(this.#s&&e){e=new Response(e.body,e);for(const[t,r]of this.#s.headers.entries())if(t!=="content-type")if(t==="set-cookie"){const s=this.#s.headers.getSetCookie();e.headers.delete("set-cookie");for(const n of s)e.headers.append("set-cookie",n)}else e.headers.set(t,r)}this.#s=e,this.finalized=!0}render=(...e)=>(this.#c??=t=>this.html(t),this.#c(...e));setLayout=e=>this.#d=e;getLayout=()=>this.#d;setRenderer=e=>{this.#c=e};header=(e,t,r)=>{this.finalized&&(this.#s=new Response(this.#s.body,this.#s));const s=this.#s?this.#s.headers:this.#a??=new Headers;t===void 0?s.delete(e):r?.append?s.append(e,t):s.set(e,t)};status=e=>{this.#o=e};set=(e,t)=>{this.#r??=new Map,this.#r.set(e,t)};get=e=>this.#r?this.#r.get(e):void 0;get var(){return this.#r?Object.fromEntries(this.#r):{}}#i(e,t,r){const s=this.#s?new Headers(this.#s.headers):this.#a??new Headers;if(typeof t=="object"&&"headers"in t){const o=t.headers instanceof Headers?t.headers:new Headers(t.headers);for(const[i,l]of o)i.toLowerCase()==="set-cookie"?s.append(i,l):s.set(i,l)}if(r)for(const[o,i]of Object.entries(r))if(typeof i=="string")s.set(o,i);else{s.delete(o);for(const l of i)s.append(o,l)}const n=typeof t=="number"?t:t?.status??this.#o;return new Response(e,{status:n,headers:s})}newResponse=(...e)=>this.#i(...e);body=(e,t,r)=>this.#i(e,t,r);text=(e,t,r)=>!this.#a&&!this.#o&&!t&&!r&&!this.finalized?new Response(e):this.#i(e,t,_(Ce,r));json=(e,t,r)=>this.#i(JSON.stringify(e),t,_("application/json",r));html=(e,t,r)=>{const s=n=>this.#i(n,t,_("text/html; charset=UTF-8",r));return typeof e=="object"?Z(e,Se.Stringify,!1,{}).then(s):s(e)};redirect=(e,t)=>{const r=String(e);return this.header("Location",/[^\x00-\xFF]/.test(r)?encodeURI(r):r),this.newResponse(null,t??302)};notFound=()=>(this.#l??=()=>new Response,this.#l(this))},m="ALL",je="all",Ne=["get","post","put","delete","options","patch"],ee="Can not add a route since the matcher is already built.",te=class extends Error{},Te="__COMPOSED_HANDLER",De=e=>e.text("404 Not Found",404),q=(e,t)=>{if("getResponse"in e){const r=e.getResponse();return t.newResponse(r.body,r)}return console.error(e),t.text("Internal Server Error",500)},ke=class re{get;post;put;delete;options;patch;all;on;use;router;getPath;_basePath="/";#t="/";routes=[];constructor(t={}){[...Ne,je].forEach(o=>{this[o]=(i,...l)=>(typeof i=="string"?this.#t=i:this.#o(o,this.#t,i),l.forEach(a=>{this.#o(o,this.#t,a)}),this)}),this.on=(o,i,...l)=>{for(const a of[i].flat()){this.#t=a;for(const c of[o].flat())l.map(d=>{this.#o(c.toUpperCase(),this.#t,d)})}return this},this.use=(o,...i)=>(typeof o=="string"?this.#t=o:(this.#t="*",i.unshift(o)),i.forEach(l=>{this.#o(m,this.#t,l)}),this);const{strict:s,...n}=t;Object.assign(this,n),this.getPath=s??!0?t.getPath??z:Re}#e(){const t=new re({router:this.router,getPath:this.getPath});return t.errorHandler=this.errorHandler,t.#r=this.#r,t.routes=this.routes,t}#r=De;errorHandler=q;route(t,r){const s=this.basePath(t);return r.routes.map(n=>{let o;r.errorHandler===q?o=n.handler:(o=async(i,l)=>(await B([],r.errorHandler)(i,()=>n.handler(i,l))).res,o[Te]=n.handler),s.#o(n.method,n.path,o)}),this}basePath(t){const r=this.#e();return r._basePath=A(this._basePath,t),r}onError=t=>(this.errorHandler=t,this);notFound=t=>(this.#r=t,this);mount(t,r,s){let n,o;s&&(typeof s=="function"?o=s:(o=s.optionHandler,s.replaceRequest===!1?n=a=>a:n=s.replaceRequest));const i=o?a=>{const c=o(a);return Array.isArray(c)?c:[c]}:a=>{let c;try{c=a.executionCtx}catch{}return[a.env,c]};n||=(()=>{const a=A(this._basePath,t),c=a==="/"?0:a.length;return d=>{const h=new URL(d.url);return h.pathname=h.pathname.slice(c)||"/",new Request(h,d)}})();const l=async(a,c)=>{const d=await r(n(a.req.raw),...i(a));if(d)return d;await c()};return this.#o(m,A(t,"*"),l),this}#o(t,r,s){t=t.toUpperCase(),r=A(this._basePath,r);const n={basePath:this._basePath,path:r,method:t,handler:s};this.router.add(t,r,[s,n]),this.routes.push(n)}#n(t,r){if(t instanceof Error)return this.errorHandler(t,r);throw t}#s(t,r,s,n){if(n==="HEAD")return(async()=>new Response(null,await this.#s(t,r,s,"GET")))();const o=this.getPath(t,{env:s}),i=this.router.match(n,o),l=new Ae(t,{path:o,matchResult:i,env:s,executionCtx:r,notFoundHandler:this.#r});if(i[0].length===1){let c;try{c=i[0][0][0][0](l,async()=>{l.res=await this.#r(l)})}catch(d){return this.#n(d,l)}return c instanceof Promise?c.then(d=>d||(l.finalized?l.res:this.#r(l))).catch(d=>this.#n(d,l)):c??this.#r(l)}const a=B(i[0],this.errorHandler,this.#r);return(async()=>{try{const c=await a(l);if(!c.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return c.res}catch(c){return this.#n(c,l)}})()}fetch=(t,...r)=>this.#s(t,r[1],r[0],t.method);request=(t,r,s,n)=>t instanceof Request?this.fetch(r?new Request(t,r):t,s,n):(t=t.toString(),this.fetch(new Request(/^https?:\/\//.test(t)?t:`http://localhost${A("/",t)}`,r),s,n));fire=()=>{addEventListener("fetch",t=>{t.respondWith(this.#s(t.request,t,void 0,t.request.method))})}},se=[];function He(e,t){const r=this.buildAllMatchers(),s=((n,o)=>{const i=r[n]||r[m],l=i[2][o];if(l)return l;const a=o.match(i[0]);if(!a)return[[],se];const c=a.indexOf("",1);return[i[1][c],a]});return this.match=s,s(e,t)}var $="[^/]+",D=".*",k="(?:|/.*)",j=Symbol(),$e=new Set(".\\+*[^]$()");function Ie(e,t){return e.length===1?t.length===1?e<t?-1:1:-1:t.length===1||e===D||e===k?1:t===D||t===k?-1:e===$?1:t===$?-1:e.length===t.length?e<t?-1:1:t.length-e.length}var _e=class L{#t;#e;#r=Object.create(null);insert(t,r,s,n,o){if(t.length===0){if(this.#t!==void 0)throw j;if(o)return;this.#t=r;return}const[i,...l]=t,a=i==="*"?l.length===0?["","",D]:["","",$]:i==="/*"?["","",k]:i.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let c;if(a){const d=a[1];let h=a[2]||$;if(d&&a[2]&&(h===".*"||(h=h.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(h))))throw j;if(c=this.#r[h],!c){if(Object.keys(this.#r).some(u=>u!==D&&u!==k))throw j;if(o)return;c=this.#r[h]=new L,d!==""&&(c.#e=n.varIndex++)}!o&&d!==""&&s.push([d,c.#e])}else if(c=this.#r[i],!c){if(Object.keys(this.#r).some(d=>d.length>1&&d!==D&&d!==k))throw j;if(o)return;c=this.#r[i]=new L}c.insert(l,r,s,n,o)}buildRegExpStr(){const r=Object.keys(this.#r).sort(Ie).map(s=>{const n=this.#r[s];return(typeof n.#e=="number"?`(${s})@${n.#e}`:$e.has(s)?`\\${s}`:s)+n.buildRegExpStr()});return typeof this.#t=="number"&&r.unshift(`#${this.#t}`),r.length===0?"":r.length===1?r[0]:"(?:"+r.join("|")+")"}},Le=class{#t={varIndex:0};#e=new _e;insert(e,t,r){const s=[],n=[];for(let i=0;;){let l=!1;if(e=e.replace(/\{[^}]+\}/g,a=>{const c=`@\\${i}`;return n[i]=[c,a],i++,l=!0,c}),!l)break}const o=e.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let i=n.length-1;i>=0;i--){const[l]=n[i];for(let a=o.length-1;a>=0;a--)if(o[a].indexOf(l)!==-1){o[a]=o[a].replace(l,n[i][1]);break}}return this.#e.insert(o,t,s,this.#t,r),s}buildRegExp(){let e=this.#e.buildRegExpStr();if(e==="")return[/^$/,[],[]];let t=0;const r=[],s=[];return e=e.replace(/#(\d+)|@(\d+)|\.\*\$/g,(n,o,i)=>o!==void 0?(r[++t]=Number(o),"$()"):(i!==void 0&&(s[Number(i)]=++t),"")),[new RegExp(`^${e}`),r,s]}},Xe=[/^$/,[],Object.create(null)],ne=Object.create(null);function oe(e){return ne[e]??=new RegExp(e==="*"?"":`^${e.replace(/\/\*$|([.\\+*[^\]$()])/g,(t,r)=>r?`\\${r}`:"(?:|/.*)")}$`)}function Me(){ne=Object.create(null)}function Fe(e){const t=new Le,r=[];if(e.length===0)return Xe;const s=e.map(c=>[!/\*|\/:/.test(c[0]),...c]).sort(([c,d],[h,u])=>c?1:h?-1:d.length-u.length),n=Object.create(null);for(let c=0,d=-1,h=s.length;c<h;c++){const[u,p,v]=s[c];u?n[p]=[v.map(([b])=>[b,Object.create(null)]),se]:d++;let f;try{f=t.insert(p,d,u)}catch(b){throw b===j?new te(p):b}u||(r[d]=v.map(([b,x])=>{const E=Object.create(null);for(x-=1;x>=0;x--){const[O,w]=f[x];E[O]=w}return[b,E]}))}const[o,i,l]=t.buildRegExp();for(let c=0,d=r.length;c<d;c++)for(let h=0,u=r[c].length;h<u;h++){const p=r[c][h]?.[1];if(!p)continue;const v=Object.keys(p);for(let f=0,b=v.length;f<b;f++)p[v[f]]=l[p[v[f]]]}const a=[];for(const c in i)a[c]=r[i[c]];return[o,a,n]}function C(e,t){if(e){for(const r of Object.keys(e).sort((s,n)=>n.length-s.length))if(oe(r).test(t))return[...e[r]]}}var Be=class{name="RegExpRouter";#t;#e;constructor(){this.#t={[m]:Object.create(null)},this.#e={[m]:Object.create(null)}}add(e,t,r){const s=this.#t,n=this.#e;if(!s||!n)throw new Error(ee);s[e]||[s,n].forEach(l=>{l[e]=Object.create(null),Object.keys(l[m]).forEach(a=>{l[e][a]=[...l[m][a]]})}),t==="/*"&&(t="*");const o=(t.match(/\/:/g)||[]).length;if(/\*$/.test(t)){const l=oe(t);e===m?Object.keys(s).forEach(a=>{s[a][t]||=C(s[a],t)||C(s[m],t)||[]}):s[e][t]||=C(s[e],t)||C(s[m],t)||[],Object.keys(s).forEach(a=>{(e===m||e===a)&&Object.keys(s[a]).forEach(c=>{l.test(c)&&s[a][c].push([r,o])})}),Object.keys(n).forEach(a=>{(e===m||e===a)&&Object.keys(n[a]).forEach(c=>l.test(c)&&n[a][c].push([r,o]))});return}const i=V(t)||[t];for(let l=0,a=i.length;l<a;l++){const c=i[l];Object.keys(n).forEach(d=>{(e===m||e===d)&&(n[d][c]||=[...C(s[d],c)||C(s[m],c)||[]],n[d][c].push([r,o-a+l+1]))})}}match=He;buildAllMatchers(){const e=Object.create(null);return Object.keys(this.#e).concat(Object.keys(this.#t)).forEach(t=>{e[t]||=this.#r(t)}),this.#t=this.#e=void 0,Me(),e}#r(e){const t=[];let r=e===m;return[this.#t,this.#e].forEach(s=>{const n=s[e]?Object.keys(s[e]).map(o=>[o,s[e][o]]):[];n.length!==0?(r||=!0,t.push(...n)):e!==m&&t.push(...Object.keys(s[m]).map(o=>[o,s[m][o]]))}),r?Fe(t):null}},Ue=class{name="SmartRouter";#t=[];#e=[];constructor(e){this.#t=e.routers}add(e,t,r){if(!this.#e)throw new Error(ee);this.#e.push([e,t,r])}match(e,t){if(!this.#e)throw new Error("Fatal error");const r=this.#t,s=this.#e,n=r.length;let o=0,i;for(;o<n;o++){const l=r[o];try{for(let a=0,c=s.length;a<c;a++)l.add(...s[a]);i=l.match(e,t)}catch(a){if(a instanceof te)continue;throw a}this.match=l.match.bind(l),this.#t=[l],this.#e=void 0;break}if(o===n)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,i}get activeRouter(){if(this.#e||this.#t.length!==1)throw new Error("No active router has been determined yet.");return this.#t[0]}},T=Object.create(null),qe=class ie{#t;#e;#r;#o=0;#n=T;constructor(t,r,s){if(this.#e=s||Object.create(null),this.#t=[],t&&r){const n=Object.create(null);n[t]={handler:r,possibleKeys:[],score:0},this.#t=[n]}this.#r=[]}insert(t,r,s){this.#o=++this.#o;let n=this;const o=be(r),i=[];for(let l=0,a=o.length;l<a;l++){const c=o[l],d=o[l+1],h=xe(c,d),u=Array.isArray(h)?h[0]:c;if(u in n.#e){n=n.#e[u],h&&i.push(h[1]);continue}n.#e[u]=new ie,h&&(n.#r.push(h),i.push(h[1])),n=n.#e[u]}return n.#t.push({[t]:{handler:s,possibleKeys:i.filter((l,a,c)=>c.indexOf(l)===a),score:this.#o}}),n}#s(t,r,s,n){const o=[];for(let i=0,l=t.#t.length;i<l;i++){const a=t.#t[i],c=a[r]||a[m],d={};if(c!==void 0&&(c.params=Object.create(null),o.push(c),s!==T||n&&n!==T))for(let h=0,u=c.possibleKeys.length;h<u;h++){const p=c.possibleKeys[h],v=d[c.score];c.params[p]=n?.[p]&&!v?n[p]:s[p]??n?.[p],d[c.score]=!0}}return o}search(t,r){const s=[];this.#n=T;let o=[this];const i=W(r),l=[];for(let a=0,c=i.length;a<c;a++){const d=i[a],h=a===c-1,u=[];for(let p=0,v=o.length;p<v;p++){const f=o[p],b=f.#e[d];b&&(b.#n=f.#n,h?(b.#e["*"]&&s.push(...this.#s(b.#e["*"],t,f.#n)),s.push(...this.#s(b,t,f.#n))):u.push(b));for(let x=0,E=f.#r.length;x<E;x++){const O=f.#r[x],w=f.#n===T?{}:{...f.#n};if(O==="*"){const P=f.#e["*"];P&&(s.push(...this.#s(P,t,f.#n)),P.#n=w,u.push(P));continue}const[F,S,R]=O;if(!d&&!(R instanceof RegExp))continue;const g=f.#e[F],de=i.slice(a).join("/");if(R instanceof RegExp){const P=R.exec(de);if(P){if(w[S]=P[0],s.push(...this.#s(g,t,f.#n,w)),Object.keys(g.#e).length){g.#n=w;const he=P[0].match(/\//)?.length??0;(l[he]||=[]).push(g)}continue}}(R===!0||R.test(d))&&(w[S]=d,h?(s.push(...this.#s(g,t,w,f.#n)),g.#e["*"]&&s.push(...this.#s(g.#e["*"],t,w,f.#n))):(g.#n=w,u.push(g)))}}o=u.concat(l.shift()??[])}return s.length>1&&s.sort((a,c)=>a.score-c.score),[s.map(({handler:a,params:c})=>[a,c])]}},Ge=class{name="TrieRouter";#t;constructor(){this.#t=new qe}add(e,t,r){const s=V(t);if(s){for(let n=0,o=s.length;n<o;n++)this.#t.insert(e,s[n],r);return}this.#t.insert(e,t,r)}match(e,t){return this.#t.search(e,t)}},ae=class extends ke{constructor(e={}){super(e),this.router=e.router??new Ue({routers:[new Be,new Ge]})}},Ke=e=>{const r={...{origin:"*",allowMethods:["GET","HEAD","PUT","POST","DELETE","PATCH"],allowHeaders:[],exposeHeaders:[]},...e},s=(o=>typeof o=="string"?o==="*"?()=>o:i=>o===i?i:null:typeof o=="function"?o:i=>o.includes(i)?i:null)(r.origin),n=(o=>typeof o=="function"?o:Array.isArray(o)?()=>o:()=>[])(r.allowMethods);return async function(i,l){function a(d,h){i.res.headers.set(d,h)}const c=await s(i.req.header("origin")||"",i);if(c&&a("Access-Control-Allow-Origin",c),r.credentials&&a("Access-Control-Allow-Credentials","true"),r.exposeHeaders?.length&&a("Access-Control-Expose-Headers",r.exposeHeaders.join(",")),i.req.method==="OPTIONS"){r.origin!=="*"&&a("Vary","Origin"),r.maxAge!=null&&a("Access-Control-Max-Age",r.maxAge.toString());const d=await n(i.req.header("origin")||"",i);d.length&&a("Access-Control-Allow-Methods",d.join(","));let h=r.allowHeaders;if(!h?.length){const u=i.req.header("Access-Control-Request-Headers");u&&(h=u.split(/\s*,\s*/))}return h?.length&&(a("Access-Control-Allow-Headers",h.join(",")),i.res.headers.append("Vary","Access-Control-Request-Headers")),i.res.headers.delete("Content-Length"),i.res.headers.delete("Content-Type"),new Response(null,{headers:i.res.headers,status:204,statusText:"No Content"})}await l(),r.origin!=="*"&&i.header("Vary","Origin",{append:!0})}},We={crossOriginEmbedderPolicy:["Cross-Origin-Embedder-Policy","require-corp"],crossOriginResourcePolicy:["Cross-Origin-Resource-Policy","same-origin"],crossOriginOpenerPolicy:["Cross-Origin-Opener-Policy","same-origin"],originAgentCluster:["Origin-Agent-Cluster","?1"],referrerPolicy:["Referrer-Policy","no-referrer"],strictTransportSecurity:["Strict-Transport-Security","max-age=15552000; includeSubDomains"],xContentTypeOptions:["X-Content-Type-Options","nosniff"],xDnsPrefetchControl:["X-DNS-Prefetch-Control","off"],xDownloadOptions:["X-Download-Options","noopen"],xFrameOptions:["X-Frame-Options","SAMEORIGIN"],xPermittedCrossDomainPolicies:["X-Permitted-Cross-Domain-Policies","none"],xXssProtection:["X-XSS-Protection","0"]},ze={crossOriginEmbedderPolicy:!1,crossOriginResourcePolicy:!0,crossOriginOpenerPolicy:!0,originAgentCluster:!0,referrerPolicy:!0,strictTransportSecurity:!0,xContentTypeOptions:!0,xDnsPrefetchControl:!0,xDownloadOptions:!0,xFrameOptions:!0,xPermittedCrossDomainPolicies:!0,xXssProtection:!0,removePoweredBy:!0,permissionsPolicy:{}},Ve=e=>{const t={...ze,...e},r=Je(t),s=[];if(t.contentSecurityPolicy){const[n,o]=G(t.contentSecurityPolicy);n&&s.push(n),r.push(["Content-Security-Policy",o])}if(t.contentSecurityPolicyReportOnly){const[n,o]=G(t.contentSecurityPolicyReportOnly);n&&s.push(n),r.push(["Content-Security-Policy-Report-Only",o])}return t.permissionsPolicy&&Object.keys(t.permissionsPolicy).length>0&&r.push(["Permissions-Policy",Ye(t.permissionsPolicy)]),t.reportingEndpoints&&r.push(["Reporting-Endpoints",Ze(t.reportingEndpoints)]),t.reportTo&&r.push(["Report-To",et(t.reportTo)]),async function(o,i){const l=s.length===0?r:s.reduce((a,c)=>c(o,a),r);await i(),tt(o,l),t?.removePoweredBy&&o.res.headers.delete("X-Powered-By")}};function Je(e){return Object.entries(We).filter(([t])=>e[t]).map(([t,r])=>{const s=e[t];return typeof s=="string"?[r[0],s]:r})}function G(e){const t=[],r=[];for(const[s,n]of Object.entries(e)){const o=Array.isArray(n)?n:[n];o.forEach((i,l)=>{if(typeof i=="function"){const a=l*2+2+r.length;t.push((c,d)=>{d[a]=i(c,s)})}}),r.push(s.replace(/[A-Z]+(?![a-z])|[A-Z]/g,(i,l)=>l?"-"+i.toLowerCase():i.toLowerCase()),...o.flatMap(i=>[" ",i]),"; ")}return r.pop(),t.length===0?[void 0,r.join("")]:[(s,n)=>n.map(o=>{if(o[0]==="Content-Security-Policy"||o[0]==="Content-Security-Policy-Report-Only"){const i=o[1].slice();return t.forEach(l=>{l(s,i)}),[o[0],i.join("")]}else return o}),r]}function Ye(e){return Object.entries(e).map(([t,r])=>{const s=Qe(t);if(typeof r=="boolean")return`${s}=${r?"*":"none"}`;if(Array.isArray(r)){if(r.length===0)return`${s}=()`;if(r.length===1&&(r[0]==="*"||r[0]==="none"))return`${s}=${r[0]}`;const n=r.map(o=>["self","src"].includes(o)?o:`"${o}"`);return`${s}=(${n.join(" ")})`}return""}).filter(Boolean).join(", ")}function Qe(e){return e.replace(/([a-z\d])([A-Z])/g,"$1-$2").toLowerCase()}function Ze(e=[]){return e.map(t=>`${t.name}="${t.url}"`).join(", ")}function et(e=[]){return e.map(t=>JSON.stringify(t)).join(", ")}function tt(e,t){t.forEach(([r,s])=>{e.res.headers.set(r,s)})}const y=new ae;y.use("*",Ve({contentSecurityPolicy:{defaultSrc:["'self'"],scriptSrc:["'self'","'unsafe-inline'","'unsafe-eval'","https://cdn.tailwindcss.com","https://cdn.jsdelivr.net","https://unpkg.com","https://cdnjs.cloudflare.com","https://static.cloudflareinsights.com"],styleSrc:["'self'","'unsafe-inline'","https://cdn.tailwindcss.com","https://cdn.jsdelivr.net","https://cdnjs.cloudflare.com","https://fonts.googleapis.com"],imgSrc:["'self'","data:","https:","blob:"],fontSrc:["'self'","https://cdn.jsdelivr.net","https://cdnjs.cloudflare.com","https://fonts.gstatic.com","data:"],connectSrc:["'self'","https://cloudflareinsights.com"],frameSrc:["'none'"],objectSrc:["'self'"],baseUri:["'self'"],formAction:["'self'"],upgradeInsecureRequests:[]},xFrameOptions:"DENY",xContentTypeOptions:"nosniff",referrerPolicy:"strict-origin-when-cross-origin",strictTransportSecurity:"max-age=31536000; includeSubDomains"}));y.use("/api/*",Ke({origin:"*",allowMethods:["GET","POST","OPTIONS"],allowHeaders:["Content-Type","Authorization"],maxAge:86400}));const M=e=>async t=>{const r=await t.env.ASSETS.fetch(t.req.raw);if(r.status===404)return r;const s=new Headers(r.headers);return e&&s.set("Cache-Control",e),new Response(r.body,{headers:s,status:r.status,statusText:r.statusText})},ce="public, max-age=31536000, immutable",rt="public, max-age=86400";y.on(["GET","HEAD"],"/static/*",M(ce));y.on(["GET","HEAD"],"/images/*",M(ce));y.on(["GET","HEAD"],"/data/*",M(rt));y.get("/api/settings",e=>e.json({currency:{rates:{UAH_TO_USD:.024,UAH_TO_EUR:.022,USD_TO_UAH:41.5,EUR_TO_UAH:45},updated_at:new Date().toISOString()},service:{name:"NEXX Repair",phone:"+380 00 000 0000",working_hours:"10:00 - 19:00"}}));y.post("/api/callback",async e=>{try{const t=await e.req.json(),{phone:r,name:s,device:n,problem:o}=t;if(!r||r.length<9)return e.json({success:!1,error:"Număr de telefon invalid"},400);const i=r.replace(/[^0-9+]/g,""),l="55f93eacf65e94ef55e6fed9fd41f8c4",a="https://api.remonline.app",c=218970,d=334611;let h=null,u=!1;try{const v=await(await fetch(`${a}/token/new`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`api_key=${l}`})).json();if(v.success&&v.token){const f=v.token;let E=(await(await fetch(`${a}/clients/?token=${f}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:s||"Client Website",phone:[i]})})).json()).data?.id;if(!E){const w=await(await fetch(`${a}/clients/?token=${f}&phones[]=${encodeURIComponent(i)}`)).json();w.data&&w.data.length>0&&(E=w.data[0].id)}if(E){const O=new Date().toISOString(),w=R=>{if(!R)return"";const g=R.toLowerCase();return g.includes("iphone")||g.includes("macbook")||g.includes("ipad")?"Apple":g.includes("samsung")||g.includes("galaxy")?"Samsung":g.includes("xiaomi")||g.includes("redmi")||g.includes("poco")?"Xiaomi":g.includes("huawei")||g.includes("honor")?"Huawei":""},S=await(await fetch(`${a}/order/?token=${f}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({branch_id:c,order_type:d,client_id:E,kindof_good:n?.toLowerCase().includes("macbook")?"Laptop":"Telefon",brand:w(n),model:n||"",malfunction:o||"Callback de pe website",manager_notes:`🌐 CALLBACK WEBSITE
🎁 BONUS: DIAGNOSTIC GRATUIT!
📱 ${n||"N/A"}
📞 ${i}
❓ ${o||"N/A"}
⏰ ${O}

✅ Comandă online - diagnostic gratuit inclus`})})).json();S.success&&S.data&&(h=S.data.id,u=!0)}}}catch(p){console.error("Remonline error:",p)}return e.json({success:!0,order_id:h,message:u?"Mulțumim! Vă vom contacta în câteva minute!":"Cererea a fost primită! Vă contactăm în curând."})}catch(t){return console.error("Callback error:",t),e.json({success:!1,error:"Eroare server"},500)}});y.get("/favicon.ico",e=>e.redirect("/static/favicon.ico"));y.get("/test-click",e=>e.html(`
    <!DOCTYPE html>
    <html lang="uk">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>NEXX - Click Test</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
        <!-- React 19 Production -->
        <script crossorigin src="/static/vendor/react.production.min.js"><\/script>
        <script crossorigin src="/static/vendor/react-dom.production.min.js"><\/script>
    </head>
    <body class="bg-gray-100 p-4">
        <div id="app"></div>
        <script>
        const { useState, useEffect, createElement: h } = React;
        
        const TestApp = () => {
            const [device, setDevice] = useState(null);
            const [error, setError] = useState(null);
            const [devices, setDevices] = useState([]);
            const [loading, setLoading] = useState(true);
            
            useEffect(() => {
                console.log('Loading devices...');
                fetch('/data/devices.json')
                    .then(r => r.json())
                    .then(data => {
                        console.log('Loaded', data.length, 'devices');
                        setDevices(data.slice(0, 6));
                        setLoading(false);
                    })
                    .catch(err => {
                        console.error('Error loading devices:', err);
                        setError(err.message);
                        setLoading(false);
                    });
            }, []);
            
            const handleClick = (d) => {
                console.log('%c CLICK:', 'background: green; color: white; font-size: 16px;', d.name);
                try {
                    setDevice(d);
                    console.log('%c setDevice OK', 'background: blue; color: white;');
                } catch (err) {
                    console.error('Error:', err);
                    setError(err.message);
                }
            };
            
            if (loading) return h('div', { className: 'p-8 text-center' }, 'Loading...');
            if (error) return h('div', { className: 'p-8 text-center text-red-500' }, 'Error: ' + error);
            
            if (device) {
                console.log('%c Rendering detail:', 'background: purple; color: white;', device.name);
                return h('div', { className: 'max-w-2xl mx-auto bg-white rounded-xl p-6 shadow-lg' },
                    h('button', { onClick: () => setDevice(null), className: 'mb-4 px-4 py-2 bg-gray-200 rounded-lg' }, '← Back'),
                    h('h1', { className: 'text-2xl font-bold mb-4' }, device.name),
                    h('div', { className: 'grid grid-cols-2 gap-4' },
                        h('div', { className: 'p-3 bg-gray-50 rounded' },
                            h('p', { className: 'text-xs text-gray-500' }, 'Category'),
                            h('p', { className: 'font-bold' }, device.category)
                        ),
                        h('div', { className: 'p-3 bg-gray-50 rounded' },
                            h('p', { className: 'text-xs text-gray-500' }, 'Year'),
                            h('p', { className: 'font-bold' }, device.year)
                        ),
                        h('div', { className: 'p-3 bg-gray-50 rounded' },
                            h('p', { className: 'text-xs text-gray-500' }, 'Processor'),
                            h('p', { className: 'font-bold' }, device.processor || 'N/A')
                        ),
                        h('div', { className: 'p-3 bg-gray-50 rounded' },
                            h('p', { className: 'text-xs text-gray-500' }, 'Model'),
                            h('p', { className: 'font-bold text-sm' }, device.model || 'N/A')
                        )
                    ),
                    device.charging_ic && h('div', { className: 'mt-4 p-3 bg-yellow-50 rounded' },
                        h('p', { className: 'text-xs text-yellow-600' }, 'Charging IC'),
                        h('p', { className: 'font-bold text-yellow-800' }, device.charging_ic.main)
                    ),
                    h('div', { className: 'mt-6 p-4 bg-green-100 rounded-lg text-green-800' }, '✅ Rendered OK!')
                );
            }
            
            return h('div', { className: 'max-w-4xl mx-auto' },
                h('h1', { className: 'text-2xl font-bold mb-6' }, '🧪 Click Test'),
                h('div', { className: 'grid grid-cols-2 md:grid-cols-3 gap-4' },
                    ...devices.map(d => 
                        h('div', {
                            key: d.name,
                            onClick: () => handleClick(d),
                            className: 'bg-white rounded-xl p-4 shadow cursor-pointer hover:shadow-lg border-2 border-transparent hover:border-blue-500'
                        },
                            h('p', { className: 'font-bold' }, d.name),
                            h('p', { className: 'text-sm text-gray-500' }, d.category + ' ' + d.year)
                        )
                    )
                )
            );
        };
        
        ReactDOM.createRoot(document.getElementById('app')).render(h(TestApp));
        <\/script>
    </body>
    </html>
  `));y.get("/nexx",e=>e.html(`
    <!DOCTYPE html>
    <html lang="uk">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>NEXX Database - Apple Repair</title>
        <meta name="description" content="NEXX Database - База данных для ремонта устройств Apple: цены, платы, микросхемы">
        <link rel="icon" type="image/png" href="/static/nexx-logo.png">
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
        
        <!-- React 19 Production -->
        <script crossorigin src="/static/vendor/react.production.min.js"><\/script>
        <script crossorigin src="/static/vendor/react-dom.production.min.js"><\/script>
    </head>
    <body class="bg-gray-50">
        <div id="app"></div>
        
        <!-- Pincode Protection + NEXX Database App -->
        <script>
        (() => {
          const { useState, createElement: h } = React;
          const { createRoot } = ReactDOM;
          const CORRECT_PIN = '31618585';
          const container = document.getElementById('app');
          let root = null;
          let isDatabaseLoading = false;

          const setLoader = (message) => {
            const text = message || 'Загрузка базы данных...';
            container.innerHTML = '<div class="min-h-screen bg-gray-50 flex items-center justify-center"><div class="bg-white rounded-2xl shadow-2xl px-8 py-6 text-center"><div class="w-12 h-12 mx-auto mb-4 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div><p class="text-slate-600 font-semibold">' + text + '</p></div></div>';
          };

          const loadDatabaseApp = () => {
            if (isDatabaseLoading || document.getElementById('nexx-db-script')) {
              return;
            }
            isDatabaseLoading = true;

            if (root) {
              root.unmount();
              root = null;
            }

            setLoader();

            const script = document.createElement('script');
            script.id = 'nexx-db-script';
            script.src = '/static/client-v2.js?v=2.0.1';
            script.async = true;
            script.onload = () => {
              container.innerHTML = '';
            };
            script.onerror = () => {
              isDatabaseLoading = false;
              container.innerHTML = '<div class="min-h-screen bg-red-50 flex items-center justify-center"><div class="bg-white rounded-2xl shadow-xl px-8 py-6 text-center"><p class="text-red-600 font-semibold mb-3">Не удалось загрузить базу данных</p><button id="retry-load" class="px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg">Повторить</button></div></div>';
              script.remove();
              const retry = document.getElementById('retry-load');
              if (retry) {
                retry.addEventListener('click', () => {
                  loadDatabaseApp();
                }, { once: true });
              }
            };
            document.body.appendChild(script);
          };

          const PincodeScreen = () => {
            const [pin, setPin] = useState('');
            const [error, setError] = useState(false);

            const handleSubmit = (event) => {
              event.preventDefault();
              if (pin === CORRECT_PIN) {
                localStorage.setItem('nexx_auth', 'true');
                loadDatabaseApp();
              } else {
                setError(true);
                setPin('');
                setTimeout(() => setError(false), 2000);
              }
            };

            return h('div', { className: 'min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center p-4' },
              h('div', { className: 'bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md' },
                h('div', { className: 'text-center mb-8' },
                  h('div', { className: 'text-6xl mb-4' }, '🔐'),
                  h('h1', { className: 'text-2xl font-bold text-slate-800 mb-2' }, 'NEXX Database'),
                  h('p', { className: 'text-slate-600' }, 'Введите пинкод для доступа')
                ),
                h('form', { onSubmit: handleSubmit },
                  h('input', {
                    type: 'password',
                    value: pin,
                    onChange: (event) => setPin(event.target.value),
                    placeholder: 'Пинкод',
                    maxLength: 8,
                    className: 'w-full px-4 py-3 text-center text-2xl tracking-widest rounded-lg border-2 ' + 
                      (error ? 'border-red-500 bg-red-50' : 'border-slate-300 focus:border-indigo-500') + 
                      ' focus:outline-none transition-all',
                    autoFocus: true
                  }),
                  error && h('p', { className: 'text-red-500 text-sm mt-2 text-center' }, '❌ Неверный пинкод'),
                  h('button', {
                    type: 'submit',
                    className: 'w-full mt-4 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg transition-all shadow-lg hover:shadow-xl'
                  }, 'Войти')
                ),
                h('div', { className: 'mt-6 text-center text-xs text-slate-500' },
                  'Protected access only'
                )
              )
            );
          };

          const init = () => {
            if (localStorage.getItem('nexx_auth') === 'true') {
              loadDatabaseApp();
            } else {
              root = createRoot(container);
              root.render(h(PincodeScreen));
            }
          };

          init();
        })();
        <\/script>
    </body>
    </html>
  `));y.post("/api/booking",async e=>{try{const t=await e.req.json();return console.log("Booking received:",t),await new Promise(r=>setTimeout(r,500)),e.json({success:!0,message:"Заявка успішно відправлена! Ми зв'яжемося з вами найближчим часом.",orderId:"TEST-"+Date.now()})}catch{return e.json({success:!1,message:"Помилка при обробці заявки. Спробуйте ще раз."},500)}});const N=(e,t,r,s="bg-white",n=!1)=>`
    <!DOCTYPE html>
    <html lang="uk">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${e}</title>
        <meta name="description" content="${t}">
        <link rel="icon" type="image/png" href="/static/nexx-logo.png">
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
        <!-- React 19 Production -->
        <script crossorigin src="/static/vendor/react.production.min.js"><\/script>
        <script crossorigin src="/static/vendor/react-dom.production.min.js"><\/script>
        ${n?`<!-- Babel Standalone for JSX transformation -->
        <script src="/static/vendor/babel.min.js"><\/script>`:""}
        <style>
          html { scroll-behavior: smooth; }
        </style>
    </head>
    <body class="${s}">
        <div id="header"></div>
        <div id="app"></div>
        <div id="footer"></div>
        
        <!-- Shared Components (Header + Footer) -->
        <script src="/static/shared-components.js"><\/script>
        <script>
          // Render Header
          const headerRoot = ReactDOM.createRoot(document.getElementById('header'));
          headerRoot.render(React.createElement(window.NEXXShared.Header));
          
          // Render Footer
          const footerRoot = ReactDOM.createRoot(document.getElementById('footer'));
          footerRoot.render(React.createElement(window.NEXXShared.Footer));
        <\/script>
        
        <!-- Page-specific content -->
        <script ${n?'type="text/babel"':""} src="/static/${r}"><\/script>
    </body>
    </html>
  `;y.get("/calculator",e=>e.html(N("Calculator preț reparații - NEXX","Calculează prețul reparației dispozitivului tău online. iPhone, Android, MacBook, iPad, Apple Watch.","calculator.js","bg-slate-50")));y.get("/about",e=>e.html(N("Despre noi - NEXX Service Center","Istoria NEXX - centru de service profesional Apple în București. Echipa noastră, valori și experiență.","about.js","bg-white",!0)));y.get("/faq",e=>e.html(N("Întrebări frecvente (FAQ) - NEXX","Răspunsuri la cele mai frecvente întrebări despre reparații Apple: garanție, termen, plată, livrare.","faq.js","bg-slate-50",!0)));y.get("/privacy",e=>e.html(N("Politica de confidențialitate - NEXX","Politica de confidențialitate NEXX Service Center. Protecția datelor personale conform GDPR.","privacy.js","bg-white",!0)));y.get("/terms",e=>e.html(N("Termeni și condiții - NEXX","Termeni și condiții NEXX Service Center. Reguli și condiții pentru reparații Apple.","terms.js","bg-white",!0)));y.get("/",async e=>{const t=await e.env.ASSETS.fetch(new Request(new URL("/index.html",e.req.url)));return t.ok?new Response(t.body,{headers:{"Content-Type":"text/html; charset=UTF-8","Cache-Control":"public, max-age=3600"}}):e.html(N("Reparații iPhone, MacBook, Samsung București | Service Rapid 30 min | NEXX ⭐","Service profesional reparații iPhone, MacBook, Samsung în București ⭐ Garanție 30 zile • Diagnostic gratuit • De la 60 lei","homepage.js"))});const K=new ae,st=Object.assign({"/src/index.tsx":y});let le=!1;for(const[,e]of Object.entries(st))e&&(K.route("/",e),K.notFound(e.notFoundHandler),le=!0);if(!le)throw new Error("Can't import modules from ['/src/index.tsx','/app/server.ts']");export{K as default};
